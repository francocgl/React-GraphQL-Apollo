import getFormatPriceNumber from './getFormatPriceNumber'

export { getFormatPriceNumber }
